let x;
let y;

function setup() {
  createCanvas(800, 800);
  x = random(400);
  x = int(x);
  y = random(400);
  y = int(y);
}

function draw() {
  background(220,0,0);
  let distanciaX;
  let distanciaY;
  let distancia;
  distanciaX = mouseX - x;
  distanciaY = mouseY - y;
  //distancia = sqrt(distanciaX*distanciaX + distanciaY*distanciaY);
  distancia = dist(mouseX,mouseY,x,y);
  fill(0,0,0)
  circle(mouseX, mouseY, distancia);
  //circle(x, y, 10);
  //console.log(distancia);
  textSize(60)

  if (distancia < 2) {
    text("ACHO QUE VC GANHOU !", 400, 400);
    noLoop();
  }
}